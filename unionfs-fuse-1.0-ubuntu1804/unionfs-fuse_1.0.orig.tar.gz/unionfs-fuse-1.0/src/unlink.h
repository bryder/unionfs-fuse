/*
* License: BSD-style license
* Copyright: Radek Podgorny <radek@podgorny.cz>,
*            Bernd Schubert <bernd-schubert@gmx.de>
*/

#ifndef UNLINK_H
#define UNLINK_H

int unionfs_unlink(const char *path);

#endif
