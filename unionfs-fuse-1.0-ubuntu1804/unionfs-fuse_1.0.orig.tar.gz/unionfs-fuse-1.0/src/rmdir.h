/*
* License: BSD-style license
* Copyright: Radek Podgorny <radek@podgorny.cz>,
*            Bernd Schubert <bernd-schubert@gmx.de>
*/

#ifndef RMDIR_H
#define RMDIR_H

int unionfs_rmdir(const char *path);

#endif
