/*
* License: BSD-style license
* Copyright: Radek Podgorny <radek@podgorny.cz>,
*/

#ifndef _VERSION_H
#define VERSION "1.0"
#endif
